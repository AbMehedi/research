import java.awt.*;
import java.awt.event.*;

public class GameBoard {
    private final Panel gamePanel;       // Panel containing the buttons
    private final Button[] buttons;      // Array of buttons (grid)
    private final GameFrame gameFrame;   // Reference to the main frame
    private int flag;                    // Toggle between X and O

    public GameBoard(GameFrame gameFrame) {
        this.gameFrame = gameFrame;
        gamePanel = new Panel(new GridLayout(3, 3));
        buttons = new Button[9];
        flag = 0;
        initializeButtons();
    }

    private void initializeButtons() {
        for (int i = 0; i < 9; i++) {
            buttons[i] = new Button("");
            buttons[i].setFont(new Font("Arial", Font.BOLD, 50));
            buttons[i].setBackground(new Color(135, 241, 224));
            buttons[i].addActionListener(this::handleButtonClick);
            gamePanel.add(buttons[i]);
        }
    }

    public Panel getPanel() {
        return gamePanel;
    }

    private void handleButtonClick(ActionEvent e) {
        Button clickedButton = (Button) e.getSource();
        if (clickedButton.getLabel().isEmpty()) {
            clickedButton.setLabel(flag == 0 ? "X" : "O");
            clickedButton.setForeground(flag == 0 ? Color.BLUE : Color.RED);
            flag = 1 - flag;
            checkWinner();
        }
    }

    private void checkWinner() {
        int[][] winningCombinations = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
                {0, 4, 8}, {2, 4, 6}             // Diagonals
        };

        for (int[] winningCombination : winningCombinations) {
            int pos1 = winningCombination[0];
            int pos2 = winningCombination[1];
            int pos3 = winningCombination[2];

            Button b1 = buttons[pos1];
            Button b2 = buttons[pos2];
            Button b3 = buttons[pos3];

            if (!b1.getLabel().isEmpty() && b1.getLabel().equals(b2.getLabel()) && b2.getLabel().equals(b3.getLabel())) {
                gameFrame.updateScore(b1.getLabel()); // Update the score for the winner
                gameFrame.showGameOverDialog(b1.getLabel() + " wins!"); // Show the winner dialog
                return; // Exit after finding a winner
            }
        }


        if (isDraw()) {
            gameFrame.showGameOverDialog("It's a Draw!");
        }
    }

    private boolean isDraw() {
        for (Button b : buttons) {
            if (b.getLabel().isEmpty()) return false;
        }
        return true;
    }

    public void resetGame() {
        for (Button b : buttons) {
            b.setLabel("");
            b.setForeground(Color.DARK_GRAY);
        }
        flag = 0; // Reset to start with X
    }
}
