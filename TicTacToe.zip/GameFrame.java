import java.awt.*;
import java.awt.event.*;

public class GameFrame {
    private final Frame frame;               // Main game window
    private final GameBoard gameBoard;
    private final ScoreBoard scoreBoard;

    public GameFrame() {
        frame = new Frame("TIC TAC TOE");
        gameBoard = new GameBoard(this);
        scoreBoard = new ScoreBoard();
    }

    public void initialize() {
        frame.setSize(400, 500);
        frame.setLayout(new BorderLayout());

        // Add the scoreboard at the top
        frame.add(scoreBoard.getPanel(), BorderLayout.NORTH);

        // Add the game board (grid of buttons) in the center
        frame.add(gameBoard.getPanel(), BorderLayout.CENTER);

        // Add window closing behavior
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });

        centerWindow(frame);
        frame.setVisible(true);
    }

    public void updateScore(String winner) {
        scoreBoard.updateScore(winner); // Update the scoreboard
    }

    public void showGameOverDialog(String message) {
        Dialog dialog = new Dialog(frame, "Game Over", true);
        dialog.setLayout(new FlowLayout());
        dialog.add(new Label(message));
        Button ok = new Button("OK");
        ok.addActionListener(_ -> {
            dialog.setVisible(false);
            gameBoard.resetGame(); // Reset the game board
        });

        dialog.add(ok);
        dialog.setSize(250, 150);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private void centerWindow(Frame frame) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screenSize.width - frame.getWidth()) / 2;
        int y = (screenSize.height - frame.getHeight()) / 2;
        frame.setLocation(x, y);
    }
}
