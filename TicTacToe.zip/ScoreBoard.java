import java.awt.*;

public class ScoreBoard {
    private final Panel scorePanel; // Panel for the scoreboard
    private final Label scoreLabel; // Label to display the score
    private int xWins;              // Count of X wins
    private int oWins;              // Count of O wins

    public ScoreBoard() {
        scorePanel = new Panel(new FlowLayout());
        scoreLabel = new Label("X Wins: 0 | O Wins: 0");
        scoreLabel.setFont(new Font(" ", Font.ITALIC, 20));
        scorePanel.add(scoreLabel);
        xWins = 0;
        oWins = 0;
    }

    public Panel getPanel() {
        return scorePanel;
    }

    public void updateScore(String winner) {
        if (winner.equals("X")) {
            xWins++;
        } else if (winner.equals("O")) {
            oWins++;
        }
        scoreLabel.setText("X Wins: " + xWins + " | O Wins: " + oWins);
    }
}
